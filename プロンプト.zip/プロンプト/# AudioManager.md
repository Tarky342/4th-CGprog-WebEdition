# AudioManager

以下の JavaScript AudioManager クラスを OpenFrameworks の C++に移植してください。

要件:

ofSoundPlayer を使用して BGM と効果音を管理
BGM(bgm, idle)はループ再生、効果音は単発再生
効果音の重複再生をサポート(複数の ofSoundPlayer インスタンスで対応)
ミュート機能の実装
音量調整機能の実装
ファイル構成:

src/core/AudioManager.h
src/core/AudioManager.cpp

主要メソッド:

void playBGM(string key) - BGM 再生
void stopBGM() - BGM 停止
void play(string key) - 効果音再生
void stop(string key) - 効果音停止
void stopAll() - 全音声停止
void toggleMute() - ミュート切替
void setVolume(string key, float volume) - 音量設定
音声ファイルパス:

sounds/BGM.mp3
sounds/jumping.mp3
sounds/Step.mp3
sounds/idle.mp3
sounds/dead.mp3
注意点:

ofSoundPlayer の制限により、効果音の同時再生には複数インスタンスが必要
音声ファイルは bin/data/sounds/に配置
シングルトンパターンで実装することを推奨
元の JavaScript コードの動作を忠実に再現してください。
