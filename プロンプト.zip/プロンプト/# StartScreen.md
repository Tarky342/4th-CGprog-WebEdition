# StartScreen

以下の JavaScript StartScreen.js を OpenFrameworks の C++に移植してください。

要件:

スタート画面(タイトル画面)の表示と管理
背景表示とアニメーション
ゲーム開始指示テキストの表示
ハイスコア表示
入力待機状態の管理
スタート画面からゲーム開始への遷移
ファイル構成:
src/scenes/StartScreen.h
src/scenes/StartScreen.cpp
主要メンバー変数:

ofImage backgroundImage - 背景画像
int highScore - 表示するハイスコア
float blinkTimer - テキト点滅タイマー
float blinkInterval - 点滅間隔
bool isVisible - テキト表示状態
std::string gameTitle - ゲームタイトル
ofTrueTypeFont font - フォント(スコア表示用)
ofTrueTypeFont titleFont - タイトル用大きいフォント
ImageLoader* imageLoader - 画像管理への参照
AudioManager* audioManager - 音声管理への参照
主要メソッド:

void setup() - 初期化、フォント・画像読み込み
void update() - 点滅アニメーション更新
void draw() - スタート画面の描画
void setHighScore(int score) - ハイスコア設定
bool isStartRequested() - スタート指示判定
void reset() - リセット
描画要素:

背景: ゲーム背景画像またはシンプルなカラー背景
タイトル: 大きなフォントで「DINO RUN」または類似のタイトル
ゲーム開始指示: 「PRESS SPACE TO START」(点滅)
操作説明: 「JUMP: SPACE」などの補足
実装の詳細:

テキト点滅は blinkTimer で制御
点滅周期は 0.5 秒程度を推奨

点滅アニメーション例:
void update() {
blinkTimer += ofGetLastFrameTime();

    if(blinkTimer > blinkInterval) {
        isVisible = !isVisible;
        blinkTimer = 0.0f;
    }

}

void draw() {
// 背景描画
backgroundImage.draw(0, 0);

    // タイトル描画
    titleFont.drawString("DINO RUN",
        ofGetWidth()/2 - 100, 150);

    // ハイスコア描画
    font.drawString("HIGH SCORE: " +
        std::to_string(highScore), 50, 300);

    // スタート指示(点滅)
    if(isVisible) {
        font.drawString("PRESS SPACE TO START", 50, 450);
    }

    // 操作説明
    font.drawString("SPACE: Jump  M: Mute", 50, 550);

}
使用例:
// ofApp::setup()
startScreen.setup();
startScreen.setHighScore(12345);

// ofApp::update()
startScreen.update();

// ofApp::draw()
if(gameState == GameState::START) {
startScreen.draw();
}

// スタート判定
if(startScreen.isStartRequested() &&
inputManager.isActionPressed("jump")) {
game.startGame();
}

フォント管理:
// StartScreen.h で
ofTrueTypeFont titleFont;
ofTrueTypeFont font;

// setup()で
titleFont.load("fonts/arial.ttf", 60);
font.load("fonts/arial.ttf", 24);
注意点:

フォントファイルは bin/data/fonts/に配置
テキト配置は画面サイズに対応可能にする
背景はスクリーンサイズに合わせてスケーリング
ofGetLastFrameTime()でフレームレート非依存の時間更新
ハイスコアはファイル保存(デバイス再起動後も保持)
オプションテキスト点滅の速度は調整可能に
タッチ入力にも対応させる場合は mousePressed()も利用
元の JavaScript のスタート画面機能を C++で実装し、OpenFrameworks の描画システムを活用した見栄えのよい UI を実現してください。
