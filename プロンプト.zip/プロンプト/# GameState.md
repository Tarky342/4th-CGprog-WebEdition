# GameState

以下の JavaScript GameState.js を OpenFrameworks の C++に移植してください。

要件:

ゲームの状態を列挙型(enum)で定義
型安全な状態管理
状態名の文字列変換機能(デバッグ用)
ファイル構成:
src/core/GameState.h
実装方法:

方法 1: enum class (推奨)
enum class GameState {
START,
PLAYING,
PAUSED,
GAME_OVER
};

状態の種類:

START - スタート画面、ゲーム開始前
PLAYING - ゲームプレイ中
PAUSED - 一時停止中
GAME_OVER - ゲームオーバー画面

実装例:
#pragma once
#include <string>

enum class GameState {
START,
PLAYING,
PAUSED,
GAME_OVER
};

// デバッグ用: 状態を文字列に変換
inline std::string gameStateToString(GameState state) {
switch(state) {
case GameState::START: return "START";
case GameState::PLAYING: return "PLAYING";
case GameState::PAUSED: return "PAUSED";
case GameState::GAME_OVER: return "GAME_OVER";
default: return "UNKNOWN";
}
}
注意点:

#pragma once でインクルードガード
enum class を使用して名前空間の汚染を防ぐ
ヘッダーファイルのみで完結
Game.h や ofApp.h からインクルードして使用
必要に応じて operator<<をオーバーロードしてストリーム出力対応
元の JavaScript の状態定義を C++の enum class で型安全に実装してください。
