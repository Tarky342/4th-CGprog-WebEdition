# ofApp

以下は ofApp 実装用のプロンプトです。

目的

openFrameworks のエントリアプリ ofApp でゲーム全体を統合する。
最小限の責務: 初期化、毎フレーム更新、描画、入力イベントの受け取り。
設計: ofApp → Game → 各マネージャー。ofApp は Game の公開 API のみを呼ぶ。
要件

ファイル: of-src/ofApp.h, ofApp.cpp
メソッド: setup, update, draw, keyPressed, keyReleased
設定値の適用: Config::FPS, ウィンドウ設定は main.cpp 側で実施
入力は InputManager に集約し、必要に応じて Game に転送
デバッグ表示のトグル(D キー)
受け入れ基準

アプリが起動し、update/draw が毎フレーム呼ばれる
スペース等の入力が InputManager に反映される
Game::setup/update/draw が呼ばれる
D キーで FPS 等のデバッグオーバーレイを表示/非表示
参考スケルトン
#pragma once
#include "ofMain.h"

class Game; // forward declaration
class InputManager; // forward declaration

class ofApp : public ofBaseApp {
public:
void setup() override;
void update() override;
void draw() override;

    void keyPressed(int key) override;
    void keyReleased(int key) override;

private:
std::unique_ptr<Game> game;
std::unique_ptr<InputManager> input;
bool debug = false;

    void drawDebug();

};
#include "ofApp.h"
#include "config/Config.h"
#include "core/Game.h"
#include "core/InputManager.h"

//--------------------------------------------------------------
void ofApp::setup() {
ofSetFrameRate(Config::FPS);
ofSetVerticalSync(true);

    input = std::make_unique<InputManager>();
    game  = std::make_unique<Game>();
    game->setup();

}

//--------------------------------------------------------------
void ofApp::update() {
input->update();
// 必要に応じて Game が InputManager を参照 or イベント転送
game->update();
}

//--------------------------------------------------------------
void ofApp::draw() {
game->draw();
if (debug) drawDebug();
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key) {
input->keyPressed(key);
// Game 内部で入力を参照する設計 or ここで転送:
// game->handleInput(key);

    if (key == 'd' || key == 'D') {
        debug = !debug;
    }

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key) {
input->keyReleased(key);
}

//--------------------------------------------------------------
void ofApp::drawDebug() {
ofSetColor(255);
ofDrawBitmapString("FPS: " + std::to_string((int)ofGetFrameRate()), 10, 20);
}
元の JavaScript ゲームロジックを忠実に OpenFrameworks で実装し、スムーズなゲームフローと明確な状態管理を実現してください。
