# Player

以下の JavaScript Player.js を OpenFrameworks の C++に移植してください。

要件:

プレイヤーキャラクターの状態管理(アイドル、走り、ジャンプ、落下、死亡)
物理演算(重力、ジャンプ、地面との衝突)
アニメーション管理(スプライトシート対応)
入力に応じたアクション実行
衝突判定用の矩形領域
状態に応じたサウンド再生
ファイル構成:
src/entities/Player.h
src/entities/Player.cpp
プレイヤー状態:
enum class PlayerState {
IDLE,
RUNNING,
JUMPING,
FALLING,
DEAD
};
主要メンバー変数:

ofVec2f position - 位置
ofVec2f velocity - 速度
float width, height - サイズ
PlayerState state - 現在の状態
bool isGrounded - 地面にいるか
bool isAlive - 生存状態
float jumpPower - ジャンプ力
float gravity - 重力
ofImage* currentImage - 現在の画像
ImageLoader* imageLoader - 画像管理への参照
AudioManager\* audioManager - 音声管理への参照
主要メソッド:

void setup() - 初期化
void update() - 状態更新、物理演算
void draw() - 描画
void jump() - ジャンプ実行
void die() - 死亡処理
void reset() - リセット
void updatePhysics() - 物理演算
void updateState() - 状態更新
void updateAnimation() - アニメーション更新
ofRectangle getBounds() - 衝突判定用矩形取得
bool isJumping() - ジャンプ中か判定
PlayerState getState() - 状態取得
実装の詳細:

位置は ofVec2f で管理(x, y)
速度は毎フレーム位置に加算
重力は毎フレーム速度に加算
地面の高さは Config::GROUND_Y で定義
ジャンプは地面にいる時のみ可能
状態遷移に応じて画像とサウンドを切り替え
物理演算例:
void updatePhysics() {
// 重力適用
velocity.y += gravity;

    // 最大落下速度制限
    if(velocity.y > maxFallSpeed) {
        velocity.y = maxFallSpeed;
    }

    // 位置更新
    position += velocity;

    // 地面判定
    if(position.y >= groundY) {
        position.y = groundY;
        velocity.y = 0;
        isGrounded = true;
    } else {
        isGrounded = false;
    }

}
ジャンプ処理例:
void jump() {
if(isGrounded && isAlive) {
velocity.y = -jumpPower;
state = PlayerState::JUMPING;
audioManager->play("jump");
}
}
状態更新例:
void updateState() {
if(!isAlive) {
state = PlayerState::DEAD;
} else if(!isGrounded && velocity.y > 0) {
state = PlayerState::FALLING;
} else if(!isGrounded && velocity.y < 0) {
state = PlayerState::JUMPING;
} else if(isGrounded) {
state = PlayerState::RUNNING;
}
}
使用例:
// ofApp::setup()
player.setup();

// ofApp::update()
player.update();
if(inputManager.isActionPressed("jump")) {
player.jump();
}

// ofApp::draw()
player.draw();

// 衝突判定
if(obstacle.getBounds().intersects(player.getBounds())) {
player.die();
}

注意点:

Config.h から定数を読み込み(GRAVITY, JUMP_POWER など)
衝突判定はプレイヤーの中心や足元を基準に調整
アニメーション用のフレームカウンターを追加
状態遷移時のサウンド再生を忘れずに
getBounds()は当たり判定を少し小さくして調整可能に
デバッグ用に矩形を描画する機能を追加(ofNoFill(), ofDrawRectangle())
元の JavaScript のプレイヤー機能を C++で実装し、滑らかな動きと正確な物理演算を実現してください。
