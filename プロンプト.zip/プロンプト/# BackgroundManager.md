# BackgroundManager

以下の JavaScript BackgroundManager クラスを OpenFrameworks の C++に移植してください。

要件:

背景画像の管理とスクロール描画
複数の背景レイヤー(遠景・近景)をサポート
視差効果(パララックス)の実装
ゲームスピードに応じたスクロール速度調整
画像のシームレスなループ描画
ファイル構成:
src/entities/BackgroundManager.h
src/entities/BackgroundManager.cpp
主要メソッド:

void setup() - 初期化、画像読み込み
void update(float gameSpeed) - スクロール位置更新
void draw() - 背景描画
void reset() - スクロール位置リセット
void addLayer(string imagePath, float scrollSpeed) - レイヤー追加
実装の詳細:

ofImage を使用して背景画像を読み込み
各レイヤーは独立したスクロール速度を持つ
画面幅を超えたらループ描画(2 枚の画像を並べて描画)
scrollOffset 変数でスクロール位置を管理
レイヤーは vector で管理し、描画順は配列の順序通り
背景画像例:

images/background_layer1.png (遠景、スクロール速度 0.3)
images/background_layer2.png (中景、スクロール速度 0.6)
images/background_layer3.png (近景、スクロール速度 1.0)
注意点:

画像ファイルは bin/data/images/に配置
画面サイズに応じて背景をスケーリング
ofApp.h/cpp から BackgroundManager インスタンスを作成して使用
update()と draw()を適切なタイミングで呼び出す
元の JavaScript コードを参考に、OpenFrameworks の描画システムに適した実装を行ってください。
