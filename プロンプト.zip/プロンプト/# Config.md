# Config

以下の JavaScript config.js を OpenFrameworks の C++に移植してください。

要件:

ゲーム全体の設定値を一元管理
定数として定義(constexpr または const)
名前空間または Config クラスで管理
型安全な定数定義
ファイル構成:
src/config/Config.h
設定項目の例:

画面設定: SCREEN_WIDTH, SCREEN_HEIGHT, FPS
プレイヤー設定: PLAYER_WIDTH, PLAYER_HEIGHT, JUMP_POWER, GRAVITY, MAX_FALL_SPEED
ゲームバランス: INITIAL_GAME_SPEED, SPEED_INCREMENT, MAX_GAME_SPEED
障害物設定: OBSTACLE_WIDTH, OBSTACLE_HEIGHT, OBSTACLE_SPAWN_INTERVAL
スコア設定: SCORE_INCREMENT_RATE, HIGH_SCORE_BONUS
カラー設定: ofColor BACKGROUND_COLOR, ofColor TEXT_COLOR
パス設定: SOUNDS_PATH, IMAGES_PATH, FONTS_PATH

方法: 名前空間 + constexpr
namespace Config {
constexpr int SCREEN_WIDTH = 1280;
constexpr int SCREEN_HEIGHT = 720;
constexpr float GRAVITY = 0.8f;
const std::string IMAGES_PATH = "images/";
}

注意点:

ヘッダーファイルのみで完結させる
#pragma once でインクルードガード
必要に応じて ofColor や ofVec2f など openFrameworks 型を使用
文字列定数は std::string または const char\*で定義
コメントで各設定の意味を明記
グループごとにセクション分け
元の JavaScript の設定項目を参考に、C++らしい定数定義を行ってください。
