# ObstacleManager

以下の JavaScript ObstacleManager.js を OpenFrameworks の C++に移植してください。

要件:

障害物の生成、更新、描画、削除を管理
複数の障害物を同時に管理
ゲームスピードに応じた移動速度調整
画面外に出た障害物の自動削除
障害物の種類(高さ、幅、タイプ)のバリエーション
スポーン間隔の制御
ファイル構成:
src/entities/ObstacleManager.h
src/entities/ObstacleManager.cpp
障害物クラス:

主要メンバー変数:
// Obstacle.h
class Obstacle {
public:
ofVec2f position;
float width;
float height;
std::string type; // "low", "high", "flying"など
ofImage\* image;

    void update(float speed);
    void draw();
    ofRectangle getBounds();

};
std::vector<Obstacle*> obstacles - 障害物リスト
float spawnTimer - 次の生成までの時間
float spawnInterval - 生成間隔
float minSpawnInterval - 最小生成間隔
float maxSpawnInterval - 最大生成間隔
ImageLoader* imageLoader - 画像管理への参照
主要メソッド:

void setup() - 初期化
void update(float gameSpeed) - 全障害物の更新
void draw() - 全障害物の描画
void spawnObstacle() - 障害物生成
void removeOffscreenObstacles() - 画面外の障害物削除
void clear() - すべての障害物を削除
void reset() - リセット
std::vector<Obstacle\*>& getObstacles() - 障害物リスト取得
int getActiveCount() - アクティブな障害物数
実装の詳細:

障害物は vector で管理し、ポインタまたはスマートポインタを使用
spawnTimer をデクリメントし、0 以下で新しい障害物を生成
生成位置は画面右端外側(SCREEN_WIDTH + offset)
障害物タイプはランダムに選択(ofRandom()使用)
画面左端外に出た障害物は自動削除

生成ロジック例:
void spawnObstacle() {
Obstacle\* obs = new Obstacle();
obs->position.x = ofGetWidth() + 50;
obs->position.y = GROUND_Y;

    // ランダムにタイプ決定
    int type = (int)ofRandom(3);
    if(type == 0) {
        obs->width = 50;
        obs->height = 80;
        obs->type = "low";
    }
    // ...

    obstacles.push_back(obs);

}

使用例:
// ofApp::setup()
obstacleManager.setup();

// ofApp::update()
obstacleManager.update(gameSpeed);

// ofApp::draw()
obstacleManager.draw();

// 衝突判定
for(auto\* obs : obstacleManager.getObstacles()) {
if(player->getBounds().intersects(obs->getBounds())) {
gameOver();
}
}

注意点:

デストラクタで clear()を呼び出してメモリリーク防止
removeOffscreenObstacles()はイテレータの無効化に注意
障害物の削除は erase-remove イディオムまたは逆順ループ
ofRandom()で予測不可能な生成パターンを実現
衝突判定用に getBounds()で ofRectangle を返す
元の JavaScript の障害物管理機能を C++で実装し、効率的なメモリ管理と描画を行ってください。
