# utils

以下の JavaScript utils.js を OpenFrameworks の C++に移植してください。

要件:

ゲーム全体で共通して使用するユーティリティ関数群
数学計算ヘルパー関数
ランダム値生成
値の制限(クランプ)
距離計算
衝突判定ヘルパー
ログ出力ユーティリティ
ファイル操作ヘルパー(ハイスコア保存・読み込み)
文字列処理ユーティリティ
ファイル構成:
src/utils/Utils.h
src/utils/Utils.cpp
推奨される関数群:

数学関数:

float clamp(float value, float min, float max) - 値を範囲内に制限
float lerp(float a, float b, float t) - 線形補間
float map(float value, float inMin, float inMax, float outMin, float outMax) - 値の範囲変換
float distance(ofVec2f a, ofVec2f b) - 2 点間の距離
float degrees(float radians) - ラジアンから度数法へ変換
float radians(float degrees) - 度数法からラジアンへ変換
ランダム関数:

float randomFloat(float min, float max) - 指定範囲のランダム浮動小数点数
int randomInt(int min, int max) - 指定範囲のランダム整数
bool randomBool(float probability) - 確率に基づき true/false を返す
衝突判定:

bool isColliding(ofRectangle a, ofRectangle b) - 矩形同士の衝突判定
bool pointInRect(ofVec2f point, ofRectangle rect) - 点が矩形内か判定
bool circleCollision(ofVec2f center1, float radius1, ofVec2f center2, float radius2) - 円同士の衝突判定
ファイル操作:

bool saveHighScore(int score, std::string filename) - ハイスコア保存
int loadHighScore(std::string filename) - ハイスコア読み込み
bool fileExists(std::string filepath) - ファイルの存在確認
ログ・デバッグ:

void logDebug(std::string message) - デバッグログ出力
void logError(std::string message) - エラーログ出力
void logInfo(std::string message) - 情報ログ出力
文字列処理:

std::string toUpperCase(std::string str) - 大文字に変換
std::string toLowerCase(std::string str) - 小文字に変換
std::vector<std::string> split(std::string str, char delimiter) - 文字列分割
std::string trim(std::string str) - 先頭末尾の空白削除
実装例:
#pragma once
#include "ofMain.h"
#include <vector>
#include <string>
#include <fstream>

namespace Utils {
// 数学関数
float clamp(float value, float min, float max);
float lerp(float a, float b, float t);
float map(float value, float inMin, float inMax,
float outMin, float outMax);
float distance(ofVec2f a, ofVec2f b);

    // ランダム関数
    float randomFloat(float min, float max);
    int randomInt(int min, int max);
    bool randomBool(float probability = 0.5f);

    // 衝突判定
    bool isColliding(ofRectangle a, ofRectangle b);
    bool pointInRect(ofVec2f point, ofRectangle rect);
    bool circleCollision(ofVec2f center1, float radius1,
                         ofVec2f center2, float radius2);

    // ファイル操作
    bool saveHighScore(int score,
                       std::string filename = "highscore.txt");
    int loadHighScore(std::string filename = "highscore.txt");
    bool fileExists(std::string filepath);

    // ログ
    void logDebug(std::string message);
    void logError(std::string message);
    void logInfo(std::string message);

    // 文字列処理
    std::string toUpperCase(std::string str);
    std::string toLowerCase(std::string str);
    std::vector<std::string> split(std::string str,
                                    char delimiter);
    std::string trim(std::string str);

}
使用例:
// 値の制限
float speed = Utils::clamp(gameSpeed, 1.0f, 10.0f);

// ランダム値
int obstacleType = Utils::randomInt(0, 2);
float randomOffset = Utils::randomFloat(-10.0f, 10.0f);

// 衝突判定
if(Utils::isColliding(player.getBounds(),
obstacle.getBounds())) {
player.die();
}

// ハイスコア管理
Utils::saveHighScore(currentScore);
int highScore = Utils::loadHighScore();

// ログ出力
Utils::logInfo("Game started");
Utils::logError("Failed to load image");

// 文字列処理
std::string title = Utils::toUpperCase("dino run");
std::vector<std::string> parts =
Utils::split("10,20,30", ',');
注意点:

#pragma once でインクルードガード
ofMain.h をインクルードして oF フレームワークの機能を利用
ファイル操作は bin/data/からの相対パスで扱う
ランダム関数は ofRandom()を内部で使用
ログは ofLog()またはコンソール出力を使用
衝突判定は一般的な AABB(Axis-Aligned Bounding Box)を使用
ハイスコアファイルは bin/data/に保存
エラーハンドリングを適切に実装
テンプレート関数の使用で汎用性を向上可能
元の JavaScript のユーティリティ関数を C++で実装し、ゲーム全体で活用できる便利な関数群を提供してください。
