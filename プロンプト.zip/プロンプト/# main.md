# main

以下の OpenFrameworks の main.cpps セットアップと初期化処理を実装するプロンプトです。

要件:

OpenFrameworks アプリケーションのエントリーポイント
ウィンドウサイズとタイトルの設定
フレームレートの設定
初期化処理の実行
ファイル構成:
src/main.cpp
実装の詳細:

main()関数でアプリケーションを起動
ofApp インスタンスを作成
ウィンドウサイズを Config::SCREEN_WIDTHxConfig::SCREEN_HEIGHT に設定
フレームレートを Config::FPS に設定
ウィンドウタイトルを「DINO RUN」に設定
OpenGL 設定(オプション)
実装例:
#include "ofMain.h"
#include "ofApp.h"
#include "config/Config.h"

//========================================================================
int main() {
ofGLWindowSettings settings;
settings.setGLVersion(4, 1);
settings.width = Config::SCREEN_WIDTH;
settings.height = Config::SCREEN_HEIGHT;
settings.title = "DINO RUN";

    auto window = ofCreateWindow(settings);
    auto app = std::make_shared<ofApp>();
    ofRunApp(window, app);
    ofRunMainLoop();

    return 0;

}

注意点:

Config.h から画面設定を読み込む
ofApp.h をインクルード
古い OpenFrameworks バージョンの場合は ofRunApp(new ofApp())の方式を使用
新しいバージョン(0.11 以上)は ofGLWindowSettings と std::make_shared を使用
フレームレートはゲームの安定性のため重要
ウィンドウタイトルはゲーム名を明記

元の OpenFrameworks プロジェクトテンプレートに従い、シンプルで保守性の高い main.cpp を実装してください。元の OpenFrameworks プロジェクトテンプレートに従い、シンプルで保守性の高い main.cpp を実装してください。
