# Game

以下の JavaScript Game.js を OpenFrameworks の C++に移植してください。

要件:

ゲーム全体のメインロジックを管理
ゲーム状態(START, PLAYING, GAME_OVER)の管理
プレイヤー、障害物、背景、オーディオの統合管理
スコアシステムの実装
衝突判定の実装
ゲームループ(update/draw)の制御
ファイル構成:
src/core/Game.h
src/core/Game.cpp

主要メンバー変数:

GameState currentState - 現在のゲーム状態
Player* player - プレイヤーインスタンス
ObstacleManager* obstacleManager - 障害物管理
BackgroundManager* backgroundManager - 背景管理
AudioManager* audioManager - 音声管理
int score - 現在のスコア
int highScore - ハイスコア
float gameSpeed - ゲームスピード
bool isPaused - ポーズ状態
主要メソッド:

void setup() - 初期化処理
void update() - ゲームロジック更新
void draw() - 画面描画
void handleInput(int key) - 入力処理
void startGame() - ゲーム開始
void gameOver() - ゲームオーバー処理
void reset() - ゲームリセット
void checkCollision() - 衝突判定
void updateScore() - スコア更新
void togglePause() - ポーズ切替
ゲーム状態遷移:

実装の詳細:

GameState は GameState.h で enum として定義
各マネージャーはポインタまたはユニークポインタで管理
スコアは時間経過で自動増加
ゲームスピードは徐々に増加(最大値あり)
ハイスコアはファイル保存を推奨(ofBuffer 使用)
衝突判定は矩形の重なり判定(AABB)
ポーズ中は更新処理を停止、描画は継続
状態別の処理:

START: タイトル表示、スペースキーで開始
PLAYING: ゲームループ実行、スコア更新、衝突判定
GAME_OVER: リザルト表示、リスタート待機
注意点:

ofApp から Game クラスを呼び出す構造
メモリ管理に注意(デストラクタで delete またはスマートポインタ使用)
update()内で各マネージャーの update()を呼び出し
draw()内で背景 → 障害物 → プレイヤー →UI の順で描画
デバッグ用に ofDrawBitmapString()で FPS 表示を追加
元の JavaScript コードのゲームフローを忠実に再現し、OpenFrameworks のアプリケーション構造に適合させてください。
