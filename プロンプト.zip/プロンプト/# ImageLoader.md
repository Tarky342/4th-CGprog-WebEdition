# ImageLoader

以下の JavaScript ImageLoader.js を OpenFrameworks の C++に移植してください。

要件:

画像ファイルの一括読み込みと管理
キー(文字列)による画像アクセス
遅延読み込みまたは事前読み込みのサポート
エラーハンドリング(読み込み失敗時の処理)
メモリ効率的な画像管理
ファイル構成:
src/utils/ImageLoader.h
src/utils/ImageLoader.cpp
主要メンバー変数:

std::map<std::string, ofImage> images - 画像データの辞書
std::string basePath - 画像ディレクトリのベースパス
主要メソッド:

void load(string key, string filepath) - 単一画像読み込み
void loadBatch(map<string, string> imageList) - 複数画像一括読み込み
ofImage\* get(string key) - 画像取得
bool isLoaded(string key) - 読み込み済みか確認
void clear() - すべての画像をクリア
void unload(string key) - 特定の画像をアンロード
int getLoadedCount() - 読み込み済み画像数取得
実装の詳細:

ofImage を std::map で管理
ベースパスは bin/data/images/を想定
画像が存在しない場合は警告ログを出力
シングルトンパターンでの実装を推奨
画像読み込み時に ofImage::load()の戻り値でエラーチェック
使用例:
// 初期化時
ImageLoader loader;
loader.load("player", "images/player.png");
loader.loadBatch({
{"bg1", "images/background1.png"},
{"bg2", "images/background2.png"},
{"obstacle", "images/obstacle.png"}
});

// 使用時
ofImage\* playerImg = loader.get("player");
if(playerImg) {
playerImg->draw(x, y);
}
注意点:

ofImage はコピーコストが高いため、参照またはポインタで返す
存在しないキーへのアクセス時は nullptr を返す
デストラクタで clear()を呼び出してメモリ解放
ofLog()を使用してデバッグ情報を出力
画像ファイルパスは相対パス(bin/data/からの相対)
元の JavaScript の画像管理機能を C++で実装し、OpenFrameworks の ofImage を効率的に管理してください。
