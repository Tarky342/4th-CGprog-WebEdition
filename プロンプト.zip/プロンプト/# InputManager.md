# InputManager

以下の JavaScript InputManager.js を OpenFrameworks の C++に移植してください。

要件:

キーボード入力の管理
キー押下状態の追跡(押された瞬間、押されている間、離された瞬間)
マウス入力のサポート(オプション)
入力バッファリング機能
キーコンフィグ対応(キーマッピング)
ファイル構成:
src/core/InputManager.h
src/core/InputManager.cpp
主要メンバー変数:

std::map<int, bool> keysPressed - 現在押されているキー
std::map<int, bool> keysPressedLastFrame - 前フレームの状態
std::map<std::string, int> keyBindings - キーマッピング(例: "jump" -> ' ')
主要メソッド:

void update() - フレームごとの状態更新
void keyPressed(int key) - キー押下イベント
void keyReleased(int key) - キー解放イベント
bool isKeyDown(int key) - キーが押されているか
bool isKeyPressed(int key) - キーが押された瞬間か
bool isKeyReleased(int key) - キーが離された瞬間か
bool isActionPressed(string action) - アクション名で判定
void setKeyBinding(string action, int key) - キーマッピング設定
void reset() - 入力状態リセット
実装の詳細:

ofApp の keyPressed()/keyReleased()から呼び出し
update()は毎フレーム呼び出して前フレーム状態を保存
キーコードは ofKeyCode 定数を使用(OF_KEY_SPACE など)
アクション例: "jump", "pause", "restart"
シングルトンパターンまたは ofApp のメンバーとして実装
キーバインディング例:
inputManager.setKeyBinding("jump", ' '); // スペースキー
使用例:
// ofApp::update()
inputManager.update();

if(inputManager.isActionPressed("jump")) {
player->jump();
}

if(inputManager.isKeyDown(' ')) {
// スペースキーが押されている間
}

if(inputManager.isKeyPressed(OF_KEY_ESC)) {
// ESC キーが押された瞬間
}

注意点:

update()は ofApp::update()の最初に呼び出す
キーコードは大文字小文字を区別しない場合は tolower()で統一
特殊キー(OF_KEY_UP, OF_KEY_RETURN など)もサポート
デバッグモードで入力状態をログ出力
ofApp.h でインクルードして使用
元の JavaScript の入力管理機能を C++で実装し、OpenFrameworks のイベントシステムと統合してください。
