#ifndef STARTSCREEN_H
#define STARTSCREEN_H

#include <glm/glm.hpp>

/**
 * StartScreen.h - スタート画面UI・操作・演出管理
 *\n * 責務：\n * - 「START GAME」ボタンを画面中央(400,300)に描画し、ボタンサイズ200x50のマウス当たり判定を提供
 * - handleMouseClick(x,y)でマウスクリック時にボタン範囲チェック、isMouseOverButton()との併用で視覚フィードバック
 * - handleKeyPress(key)でEnterキーでゲーム開始できる別操作方法をサポート
 * - updateAnimation(deltaTime)で pulseAmount をサイン波で変動させ、ボタンをパルスエフェクト表示
 * - startRequested フラグを true に設定し、Game側でこれを読み取ってPLAYING状態へ遷移を判定
 * - acknowledgeStart()でフラグをリセットし、重複開始を防止（1フレーム1度の開始判定）
 * - draw()内で背景画像・ゲームタイトル・スタートボタン・操作説明などをレイアウト描画
 * - 複数ボタン対応(selectedButtonIndex)で将来的に設定/終了ボタン追加拡張を容易にする
 */

class StartScreen
{
public:
  StartScreen();

  // 初期化
  void initialize();
  void reset();

  // 状態管理
  bool isStartRequested() const;
  void acknowledgeStart();

  // ユーザー操作
  void handleMouseClick(int x, int y);
  void handleKeyPress(char key);

  // 更新・描画
  void update(float deltaTime);
  void draw();

  // アニメーション管理
  void updateAnimation(float deltaTime);

  // UI要素
  bool isMouseOverButton(int x, int y, int buttonIndex) const;

private:
  // 状態
  bool startRequested;

  // UI
  int selectedButtonIndex;
  int totalButtons;

  // アニメーション
  float animationTimer;
  float pulseAmount;

  // ボタンの位置
  glm::vec2 startButtonPos;
  float buttonWidth;
  float buttonHeight;
};

#endif // STARTSCREEN_H
