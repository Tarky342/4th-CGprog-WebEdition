#ifndef OFAPP_H
#define OFAPP_H

#include "ofMain.h"
#include "core/Game.h"
#include "core/InputManager.h"

/**
 * ofApp.h - OpenFrameworksメインアプリケーション・イベントハブ
 *
 * 責務：
 * - setup()内でGame・InputManager初期化、リソースプリロード（画像・音声）、フレームレート設定
 * - update()でdeltaTime計測（currentTime - lastFrameTime）、game.update(deltaTime)呼び出し
 * - draw()でopenGL背景クリア、game.draw()呼び出し、フレームレート情報などUI表示
 * - keyPressed(key) / keyReleased(key) イベントを inputManager.setKeyPressed(key, pressed) に委譲
 * - mouseMoved(x,y) イベントを inputManager.setMousePosition(x,y) に委譲
 * - mousePressed/Released イベントを inputManager.setMousePressed(bool) に委譲、UI操作対応
 * - windowResized(w,h)でウィンドウサイズ変更時にゲーム内スケーリング再計算（UI相対配置対応）
 * - exit()でリソース完全解放、ImageLoader::clearAll()、Game破棄などクリーンアップ処理
 */

class ofApp : public ofBaseApp
{
public:
  // OpenFrameworks ライフサイクル
  void setup();
  void update();
  void draw();
  void exit();

  // イベントハンドリング
  void keyPressed(int key);
  void keyReleased(int key);
  void mouseMoved(int x, int y);
  void mouseDragged(int x, int y, int button);
  void mousePressed(int x, int y, int button);
  void mouseReleased(int x, int y, int button);
  void windowResized(int w, int h);

private:
  // ゲームクラス
  Game game;
  InputManager inputManager;

  // フレームレート管理
  float deltaTime;
  float lastFrameTime;
};

#endif // OFAPP_H
