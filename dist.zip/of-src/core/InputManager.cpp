#include "InputManager.h"

/**
 * InputManager.cpp
 *
 * 実装予定の責務：
 * - キーボード入力の状態を管理する
 * - マウス入力の状態と座標を管理する
 * - 入力イベントを処理する
 * - プレイヤーの入力意図を解釈する
 */

InputManager::InputManager()
    : mousePressed(false), mouseX(0), mouseY(0)
{
  // 初期化処理
}

bool InputManager::isKeyPressed(char key) const
{
  // キーが押されているかを確認
  return false;
}

void InputManager::setKeyPressed(char key, bool pressed)
{
  // キーの状態を設定
}

void InputManager::resetAllKeys()
{
  // すべてのキー状態をリセット
}

bool InputManager::isMousePressed() const
{
  return mousePressed;
}

int InputManager::getMouseX() const
{
  return mouseX;
}

int InputManager::getMouseY() const
{
  return mouseY;
}

void InputManager::setMousePosition(int x, int y)
{
  mouseX = x;
  mouseY = y;
}

void InputManager::setMousePressed(bool pressed)
{
  mousePressed = pressed;
}

bool InputManager::wantsMoveLeft() const
{
  // 左移動意図を判定
  return false;
}

bool InputManager::wantsMoveRight() const
{
  // 右移動意図を判定
  return false;
}

bool InputManager::wantsJump() const
{
  // ジャンプ意図を判定
  return false;
}

bool InputManager::wantsPause() const
{
  // ポーズ意図を判定
  return false;
}

bool InputManager::wantsRestart() const
{
  // リスタート意図を判定
  return false;
}
