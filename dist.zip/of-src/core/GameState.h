#ifndef GAMESTATE_H
#define GAMESTATE_H

#include "../config/Config.h"

/**
 * GameState.h - ゲーム状態・スコア・統計管理
 *
 * 責務：
 * - 現在のゲーム状態（START_SCREEN/PLAYING/PAUSED/GAME_OVER）を保持し、Game側の分岐判定に使用される
 * - プレイヤーのスコアを加算・取得・リセット機能で管理し、ゲーム進行に応じて累積できる
 * - プレイヤーの生命力（health）を0～100の範囲内で管理し、ゲームオーバー判定に使用される
 * - 経過時間（elapsedTime）をフレーム毎に更新し、タイムアタックやゲーム難易度の時間進行に対応
 * - 障害物衝突回数やアイテム獲得数などの統計情報を記録し、ゲーム結果画面の表示に使用される
 * - ゲーム状態遷移時に前フレームの状態を記憶できり、ポーズ後の再開や再スタート機能を支援する
 */

class GameState
{
public:
  // 状態管理
  GameConfig::GameStateType getCurrentState() const;
  void setState(GameConfig::GameStateType newState);

  // スコア管理
  int getScore() const;
  void addScore(int points);
  void resetScore();

  // プレイヤー状態
  int getHealth() const;
  void setHealth(int health);
  void damageHealth(int damage);

  // ゲーム統計
  void resetGameStats();
  void recordObstacleCollision();
  void recordItemCollect();

  // ゲーム時間
  float getElapsedTime() const;
  void updateTime(float deltaTime);

private:
  // 状態情報
  GameConfig::GameStateType currentState;

  // ゲーム統計
  int score;
  int health;
  float elapsedTime;
};

#endif // GAMESTATE_H
