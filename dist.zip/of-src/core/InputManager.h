#ifndef INPUTMANAGER_H
#define INPUTMANAGER_H

/**
 * InputManager.h - 入力デバイス（キー・マウス）管理
 *
 * 責務：
 * - キーボード状態を256個のbool配列で管理し、フレーム内でのキープレス/リリースを記録
 * - ofApp.keyPressed/keyReleasedイベントから呼び出され、キー入力を記録・更新する
 * - マウス座標（X,Y）と押下状態を保持し、UI操作やクリック判定に提供する
 * - wantsMoveLeft/Right/Jump などの高レベルの入力意図に変換し、Game ロジックをキー配置から独立させる
 * - キー入力ポーリング形式（isKeyPressed）とイベント形式の両方に対応できる柔軟性を持つ
 * - キー入力状態はフレーム単位で更新され、Game.update内で毎フレーム読み出される
 * - ポーズ/メニュー画面とゲーム画面で異なるキー割り当てをサポート可能な設計
 */

class InputManager
{
public:
  InputManager();

  // キー入力管理
  bool isKeyPressed(char key) const;
  void setKeyPressed(char key, bool pressed);
  void resetAllKeys();

  // マウス入力管理
  bool isMousePressed() const;
  int getMouseX() const;
  int getMouseY() const;
  void setMousePosition(int x, int y);
  void setMousePressed(bool pressed);

  // プレイヤー操作解釈
  bool wantsMoveLeft() const;
  bool wantsMoveRight() const;
  bool wantsJump() const;
  bool wantsPause() const;
  bool wantsRestart() const;

private:
  // キー状態（'A', 'D', 'W', 'Space' など）
  bool keys[256];

  // マウス状態
  bool mousePressed;
  int mouseX;
  int mouseY;
};

#endif // INPUTMANAGER_H
