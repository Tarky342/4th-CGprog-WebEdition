#ifndef GAME_H
#define GAME_H

#include "GameState.h"
#include "InputManager.h"
#include "../entities/Player.h"
#include "../entities/ObstacleManager.h"
#include "../entities/BackgroundManager.h"
#include "../scenes/StartScreen.h"

/**
 * Game.h - メインゲームループと全コンポーネント統合
 *
 * 責務：\n * - update(deltaTime)内でゲーム状態（PLAYING/PAUSED/START_SCREEN/GAME_OVER）に応じた分岐処理を実行
 * - Player、ObstacleManager、BackgroundManagerの生成・初期化・更新・破棄を一元管理する
 * - updatePlayingState内でプレイヤーと障害物の位置を毎フレーム更新し、その後handleCollisions()で衝突判定を実行
 * - draw()内で背景→障害物→プレイヤーの順で描画し、正しい描画順序（Z順序）を保証する
 * - InputManagerの入力状態を読み取り、プレイヤー操作（移動・ジャンプ）に変換して適用する
 * - ゲーム状態遷移（startNewGame→PLAYING→GAME_OVER、pauseGame→PAUSED→resumeGame）をサポート
 * - 障害物衝突検出時にプレイヤーのダメージ処理を呼び出し、GameStateのスコア加算機能と統合
 */

class Game
{
public:
  Game();
  ~Game();

  // ゲーム初期化
  void initialize();

  // メインループ
  void update(float deltaTime);
  void draw();

  // イベント処理
  void handleInput(InputManager &inputManager);

  // ゲーム状態管理
  GameState &getGameState();
  void startNewGame();
  void pauseGame();
  void resumeGame();
  void endGame();

  // シーン管理
  void goToStartScreen();

private:
  // ゲームコンポーネント
  GameState gameState;
  Player player;
  ObstacleManager obstacleManager;
  BackgroundManager backgroundManager;
  StartScreen startScreen;

  // 内部状態
  bool isRunning;
  bool isPaused;

  // 更新処理
  void updatePlayingState(float deltaTime);
  void updatePausedState();
  void updateStartScreenState();
  void updateGameOverState();

  // 描画処理
  void drawPlayingState();
  void drawPausedState();
  void drawStartScreenState();
  void drawGameOverState();

  // ゲームロジック
  void handleCollisions();
  void checkGameOver();
};

#endif // GAME_H
