#ifndef CONFIG_H
#define CONFIG_H

/**
 * Config.h - ゲーム定数・グローバル設定定義
 *
 * 責務：
 * - ウィンドウサイズ（800x600）をすべてのシステムで統一的に使用可能にする
 * - ゲームループのフレームレート（60FPS）を一元管理し、異なるマシンでも同期を保つ
 * - プレイヤーの動作パラメータ（速度5.0、ジャンプ力15.0、重力9.8）を集中管理し、バランス調整時の変更を容易にする
 * - ゲーム物理の基準値（最大速度20.0）を定義し、バランス調整時の変更を容易にする
 * - ゲーム状態遷移の種類（START_SCREEN、PLAYING、PAUSED、GAME_OVER）を列挙型で定義
 * - 地面高さ（500.0）のような基準点を提供し、プレイヤーと障害物の配置に使用される
 * - すべての定数がnamespaceで囲まれており、グローバルスコープ汚染を防止
 */

namespace GameConfig
{
  // ウィンドウサイズ
  const int WINDOW_WIDTH = 800;
  const int WINDOW_HEIGHT = 600;

  // フレームレート
  const int TARGET_FPS = 60;

  // ゲーム定数（物理）
  const float GRAVITY = 9.8f;
  const float PLAYER_SPEED = 5.0f;
  const float PLAYER_JUMP_FORCE = 15.0f;
  const float MAX_VELOCITY = 20.0f;

  // ゲーム定数（マップ）
  const float GROUND_LEVEL = 500.0f;

  // ゲーム状態
  enum class GameStateType
  {
    START_SCREEN,
    PLAYING,
    PAUSED,
    GAME_OVER
  };
}

#endif // CONFIG_H
