#include "ofApp.h"

/**
 * ofApp.cpp
 *
 * 実装予定の責務：
 * - OpenFrameworksのメインアプリケーションクラス
 * - ゲームループのセットアップと実行を管理する
 * - ofの各種イベントを処理する
 * - 入力イベントをGameクラスに受け渡す
 * - ウィンドウサイズやレンダリング設定を管理する
 */

void ofApp::setup()
{
  // ゲーム初期化
}

void ofApp::update()
{
  // フレーム更新処理
}

void ofApp::draw()
{
  // フレーム描画処理
}

void ofApp::exit()
{
  // 終了処理
}

void ofApp::keyPressed(int key)
{
  // キー入力を受け取ってInputManagerに渡す
}

void ofApp::keyReleased(int key)
{
  // キー解放を受け取ってInputManagerに渡す
}

void ofApp::mouseMoved(int x, int y)
{
  // マウス移動を受け取ってInputManagerに渡す
}

void ofApp::mouseDragged(int x, int y, int button)
{
  // マウスドラッグを受け取ってInputManagerに渡す
}

void ofApp::mousePressed(int x, int y, int button)
{
  // マウスクリック（押下）を受け取ってInputManagerに渡す
}

void ofApp::mouseReleased(int x, int y, int button)
{
  // マウスクリック（解放）を受け取ってInputManagerに渡す
}

void ofApp::windowResized(int w, int h)
{
  // ウィンドウサイズ変更時の処理
}
