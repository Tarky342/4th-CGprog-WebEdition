#ifndef IMAGELOADER_H
#define IMAGELOADER_H

#include <string>
#include <map>
#include <memory>

/**
 * ImageLoader.h - 画像リソースのキャッシング・管理
 *
 * 責務：
 * - シングルトンパターン(getInstance())で唯一のインスタンスを保証、アプリ全体で一つの画像キャッシュを共有
 * - loadImage(key, path)で public/images配下のPNG/JPGファイルを読み込み、keyをキーに std::map で管理
 * - hasImage(key) で重複ロード防止、同じキーでの2度目のロード呼び出しで既存データを返す
 * - unloadImage(key) で特定の画像をメモリ解放、clearAll()ですべての画像をアンロード（終了時）
 * - getImageWidth/Height(key) で画像寸法を返し、描画時のRect設定やUI配置に使用
 * - preloadPlayerSprites() で \"player_idle\", \"player_run1\", \"player_run2\" など複数フレーム一括ロード
 * - preloadEnemySprites() で各障害物タイプのスプライト、BackgroundManager向けパーティクル画像をプリロード
 * - getTotalMemoryUsage() でキャッシュサイズを集計、メモリ管理とデバッグに使用
 */

class ImageLoader
{
public:
  // シングルトンパターン
  static ImageLoader &getInstance();

  // 画像ロード
  void loadImage(const std::string &key, const std::string &path);
  void unloadImage(const std::string &key);
  void clearAll();

  // 画像取得
  bool hasImage(const std::string &key) const;
  int getImageWidth(const std::string &key) const;
  int getImageHeight(const std::string &key) const;

  // 一括ロード
  void preloadPlayerSprites();
  void preloadEnemySprites();
  void preloadBackgroundAssets();

  // リソース管理
  int getLoadedImageCount() const;
  int getTotalMemoryUsage() const;

  // デバッグ
  void printLoadedImages() const;

private:
  ImageLoader();
  ~ImageLoader();

  // シングルトン設定
  static ImageLoader *instance;

  // 画像ストレージ
  struct ImageData
  {
    std::string path;
    int width;
    int height;
    // 実際の画像データは適切な型を使用
  };

  std::map<std::string, ImageData> imageCache;
};

#endif // IMAGELOADER_H
