#ifndef UTILS_H
#define UTILS_H

#include <string>
#include <glm/glm.hpp>

/**
 * Utils.h - ゲーム全体の数学・乱数・ファイル・デバッグ機能
 *
 * 責務：
 * - getRandomFloat/getRandomInt で [min,max) 範囲の乱数を生成、障害物スポーン位置・速度などに使用
 * - checkRectCollision(x1,y1,w1,h1, x2,y2,w2,h2) でAABB矩形衝突判定、Player と Obstacle の衝突判定に使用
 * - checkCircleCollision(center1,r1, center2,r2) で円形衝突判定、パーティクルや効果判定に対応
 * - distance(a,b) でglm::vec2間の距離を計算、オブジェクト間距離チェック（e.g.敵範囲判定）に使用
 * - clamp(value,min,max) でスカラー値を範囲内に制限、speed上限やhealth範囲制限に使用
 * - clampMagnitude(vec,maxMag) でベクトル長を上限制限、速度最大値の強制に使用
 * - readTextFile/writeTextFile でセーブデータやリソースファイルのI/O、ゲーム設定保存に対応
 * - logDebug/logWarning/logError で日本語対応のデバッグ出力をコンソールに記録
 */

namespace Utils
{
  // ランダム値生成
  float getRandomFloat(float min, float max);
  int getRandomInt(int min, int max);

  // 衝突判定
  bool checkRectCollision(float x1, float y1, float w1, float h1,
                          float x2, float y2, float w2, float h2);
  bool checkCircleCollision(glm::vec2 center1, float radius1,
                            glm::vec2 center2, float radius2);

  // ベクトル演算
  float distance(glm::vec2 a, glm::vec2 b);
  glm::vec2 normalize(glm::vec2 vec);

  // 速度制限
  float clamp(float value, float min, float max);
  float clampMagnitude(glm::vec2 &vec, float maxMagnitude);

  // ファイルI/O
  std::string readTextFile(const std::string &path);
  void writeTextFile(const std::string &path, const std::string &content);

  // 文字列操作
  std::string intToString(int value);
  int stringToInt(const std::string &str);

  // デバッグ
  void logDebug(const std::string &message);
  void logWarning(const std::string &message);
  void logError(const std::string &message);
}

#endif // UTILS_H
