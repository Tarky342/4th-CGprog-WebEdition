#include "ImageLoader.h"

/**
 * ImageLoader.cpp
 *
 * 実装予定の責務：
 * - ゲーム内で使用する画像をロードして管理する
 * - 画像リソースのキャッシング機構を提供する
 * - 重複ロードを防止し、メモリを効率的に使用する
 * - 画像の解放とリソース管理を行う
 * - 画像フォーマットの変換や最適化を行う
 */

ImageLoader *ImageLoader::instance = nullptr;

ImageLoader &ImageLoader::getInstance()
{
  if (!instance)
  {
    instance = new ImageLoader();
  }
  return *instance;
}

ImageLoader::ImageLoader()
{
}

ImageLoader::~ImageLoader()
{
  clearAll();
}

void ImageLoader::loadImage(const std::string &key, const std::string &path)
{
  // 画像をロード
}

void ImageLoader::unloadImage(const std::string &key)
{
  // 画像をアンロード
}

void ImageLoader::clearAll()
{
  imageCache.clear();
}

bool ImageLoader::hasImage(const std::string &key) const
{
  return imageCache.find(key) != imageCache.end();
}

int ImageLoader::getImageWidth(const std::string &key) const
{
  auto it = imageCache.find(key);
  if (it != imageCache.end())
  {
    return it->second.width;
  }
  return 0;
}

int ImageLoader::getImageHeight(const std::string &key) const
{
  auto it = imageCache.find(key);
  if (it != imageCache.end())
  {
    return it->second.height;
  }
  return 0;
}

void ImageLoader::preloadPlayerSprites()
{
  // プレイヤースプライトをプリロード
}

void ImageLoader::preloadEnemySprites()
{
  // 敵スプライトをプリロード
}

void ImageLoader::preloadBackgroundAssets()
{
  // 背景アセットをプリロード
}

int ImageLoader::getLoadedImageCount() const
{
  return static_cast<int>(imageCache.size());
}

int ImageLoader::getTotalMemoryUsage() const
{
  // 総メモリ使用量を計算
  return 0;
}

void ImageLoader::printLoadedImages() const
{
  // ロード済み画像をログ出力
}
