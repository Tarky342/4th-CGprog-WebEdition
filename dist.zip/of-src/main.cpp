#include "ofMain.h"
#include "ofApp.h"

/**
 * main.cpp
 *
 * 責務：
 * - OpenFrameworksアプリケーションのエントリーポイント
 * - ウィンドウサイズやウィンドウ名を設定する
 * - ofAppクラスのインスタンスを作成し、メインループを開始する
 */

int main()
{
  // ウィンドウ設定
  ofSetupOpenGL(800, 600, OF_WINDOW);

  // アプリケーション開始
  ofRunApp(new ofApp());
}
