#ifndef PLAYER_H
#define PLAYER_H

#include <glm/glm.hpp>

/**
 * Player.h - プレイヤーキャラクター状態・動作・物理管理
 *
 * 責務：
 * - position（X,Y）とvelocity（VX,VY）をglm::vec2で管理し、毎フレームの位置更新を行う
 * - applyGravity(deltaTime)でY速度に重力9.8を累積させ、自由落下をシミュレートする
 * - moveLeft/moveRight時にX速度を±5.0に設定し、MAX_VELOCITY=20.0の制限値を超えないようクランプ
 * - jump時にjumping=true、velocity.y に-15.0を設定して上方速度を付与し、groundedフラグで多段ジャンプを防止
 * - 地面判定（isGrounded）で重力の影響を受けるか決定し、空中では落下を継続
 * - updateAnimation(deltaTime)でフレーム番号をカウントアップし、0～3の4フレームアニメーションを循環
 * - getWidth/getHeight（32x48）で矩形サイズを提供し、ObstacleManager との衝突判定に使用
 * - takeDamage/getHealth で health を管理し、GameState のスコア加算機能と統合
 */

class Player
{
public:
  Player();

  // 初期化
  void initialize(float startX, float startY);

  // 位置・速度管理
  glm::vec2 getPosition() const;
  void setPosition(float x, float y);

  glm::vec2 getVelocity() const;
  void setVelocity(float vx, float vy);

  // 操作
  void moveLeft();
  void moveRight();
  void jump();
  void applyGravity(float deltaTime);

  // 状態管理
  bool isJumping() const;
  bool isGrounded() const;
  void setGrounded(bool grounded);

  // アニメーション
  void updateAnimation(float deltaTime);
  int getCurrentFrame() const;

  // 更新
  void update(float deltaTime);

  // 描画関連
  float getWidth() const;
  float getHeight() const;

  // ダメージ
  void takeDamage(int damage);
  int getHealth() const;

private:
  // 物理状態
  glm::vec2 position;
  glm::vec2 velocity;

  // 移動状態
  bool grounded;
  bool jumping;
  float jumpForce;

  // ゲーム内容
  int health;
  int maxHealth;

  // アニメーション
  int currentFrame;
  float animationTimer;
  int totalFrames;

  // サイズ
  float width;
  float height;
};

#endif // PLAYER_H
