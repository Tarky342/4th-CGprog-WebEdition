#ifndef BACKGROUNDMANAGER_H
#define BACKGROUNDMANAGER_H

#include <glm/glm.hpp>

/**
 * BackgroundManager.h - 背景スクロール・視差効果・装飾管理
 *
 * 責務：
 * - scrollOffsetをフレーム毎にscrollSpeed(100.0) * deltaTime だけ加算し、背景を左方向にシームレススクロール
 * - scrollOffset が画面幅に達したら0にリセットして、背景画像のループを実現（タイリング背景）
 * - parallaxFactor(0.5)を使用した複数レイヤーの背景描画を実装し、奥行き感を視覚的に表現
 * - setScrollSpeed(speed)でゲーム難易度に応じてスクロール速度を動的に変更可能にする
 * - 背景装飾オブジェクト（雲など）をspawnBackgroundObject()でスポーン、parallaxFactor適用後に描画
 * - update内でbackgroundObjectsの位置更新とライフタイム管理を行い、古いオブジェクトを削除
 * - draw()内でdrawLayer()を複数回呼び出し、遠景→中景→近景の順序で多層描画
 * - フレームレートに依存しない滑らかなスクロール実現のため、すべての計算にdeltaTimeを使用
 */

class BackgroundManager
{
public:
  BackgroundManager();

  // 初期化
  void initialize();
  void reset();

  // スクロール管理
  void setScrollSpeed(float speed);
  float getScrollSpeed() const;

  // 背景オブジェクト管理
  void spawnBackgroundObject();
  void removeBackgroundObject(size_t index);

  // 更新・描画
  void update(float deltaTime);
  void draw();

  // 視差効果
  void setParallaxFactor(float factor);

  // 統計
  int getActiveObjectCount() const;

private:
  // スクロール状態
  float scrollSpeed;
  float scrollOffset;

  // 視差設定
  float parallaxFactor;

  // オブジェクト管理
  int maxBackgroundObjects;
  float objectSpawnInterval;
  float spawnTimer;

  // 描画処理
  void drawLayer(int layer);
};

#endif // BACKGROUNDMANAGER_H
