#ifndef OBSTACLEMANAGER_H
#define OBSTACLEMANAGER_H

#include <vector>
#include <glm/glm.hpp>

/**
 * ObstacleManager.h - 障害物の生成・管理・衝突判定
 *
 * 責務：
 * - std::vectorで複数の障害物（Obstacle構造体）を管理し、最大20個程度まで動的に生成・破棄
 * - spawnObstacle内で画面右側からランダムな高さで障害物をスポーン、X速度-8.0で左方向へ移動
 * - update(deltaTime)ですべてのアクティブな障害物を移動させ、画面外に出た障害物をactive=falseにしてリサイクル
 * - checkCollisionWithPlayer(playerX,Y,W,H)でプレイヤー矩形と各障害物矩形のAABB衝突判定を実行
 * - 衝突検出時にゲーム側から呼び出され、衝突フラグを立てんで返すことで、Game側が衝突処理を実行
 * - difficulty値に応じてspawnRateを加速させ、ゲーム進行に伴い障害物の密度が増加する
 * - draw()内で各障害物の矩形を描画し、フレーム内すべてのアクティブなオブジェクトを画面に表示
 * - getActiveObstacleCount()でゲーム難易度の判定や統計情報の収集に使用される
 */

struct Obstacle
{
  glm::vec2 position;
  glm::vec2 velocity;
  float width;
  float height;
  int type;
  bool active;
};

class ObstacleManager
{
public:
  ObstacleManager();

  // 初期化
  void initialize();
  void reset();

  // 障害物管理
  void spawnObstacle();
  void removeObstacle(size_t index);
  void clearAll();

  // 更新・描画
  void update(float deltaTime);
  void draw();

  // 衝突判定
  bool checkCollisionWithPlayer(float playerX, float playerY,
                                float playerWidth, float playerHeight);
  const std::vector<Obstacle> &getObstacles() const;

  // 難易度管理
  void setDifficulty(float difficulty);
  void increaseDifficulty();

  // 統計
  int getActiveObstacleCount() const;

private:
  std::vector<Obstacle> obstacles;
  float spawnRate;
  float spawnTimer;
  float difficulty;

  // スポーン管理
  void updateSpawnLogic(float deltaTime);
  float getRandomSpawnPosition() const;
  Obstacle createRandomObstacle();
};

#endif // OBSTACLEMANAGER_H
