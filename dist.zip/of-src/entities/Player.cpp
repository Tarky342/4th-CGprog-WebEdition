#include "Player.h"

/**
 * Player.cpp
 *
 * 実装予定の責務：
 * - プレイヤーキャラクターの位置と速度を管理する
 * - プレイヤーのアニメーション状態を管理する
 * - プレイヤーの物理演算を処理する
 * - プレイヤーの入力を受け取り動きを更新する
 * - プレイヤーの衝突判定用の矩形情報を提供する
 */

Player::Player()
    : position(0.0f, 0.0f), velocity(0.0f, 0.0f),
      grounded(false), jumping(false), jumpForce(15.0f),
      health(100), maxHealth(100),
      currentFrame(0), animationTimer(0.0f), totalFrames(4),
      width(32.0f), height(48.0f)
{
}

void Player::initialize(float startX, float startY)
{
  position = glm::vec2(startX, startY);
  velocity = glm::vec2(0.0f, 0.0f);
  grounded = true;
  jumping = false;
}

glm::vec2 Player::getPosition() const
{
  return position;
}

void Player::setPosition(float x, float y)
{
  position = glm::vec2(x, y);
}

glm::vec2 Player::getVelocity() const
{
  return velocity;
}

void Player::setVelocity(float vx, float vy)
{
  velocity = glm::vec2(vx, vy);
}

void Player::moveLeft()
{
  // 左移動処理
}

void Player::moveRight()
{
  // 右移動処理
}

void Player::jump()
{
  // ジャンプ処理
}

void Player::applyGravity(float deltaTime)
{
  // 重力を適用
}

bool Player::isJumping() const
{
  return jumping;
}

bool Player::isGrounded() const
{
  return grounded;
}

void Player::setGrounded(bool grounded)
{
  this->grounded = grounded;
}

void Player::updateAnimation(float deltaTime)
{
  // アニメーション更新
}

int Player::getCurrentFrame() const
{
  return currentFrame;
}

void Player::update(float deltaTime)
{
  // プレイヤーの全体更新
}

float Player::getWidth() const
{
  return width;
}

float Player::getHeight() const
{
  return height;
}

void Player::takeDamage(int damage)
{
  health -= damage;
  if (health < 0)
    health = 0;
}

int Player::getHealth() const
{
  return health;
}
